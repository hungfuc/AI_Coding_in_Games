Neon Outlaw Unity Project

Instructions:
- Open this project in Unity 2022.3 LTS or newer.
- The sample scene contains Player prefab with FPSController, PlayerShooting, PlayerHealth.
- Enemy drones patrol with EnemyAI and have EnemyHealth.
- AmmoPickup and HealthPickup prefabs allow replenishing ammo and health.
- UIManager handles HUD elements: health bar, ammo count, mission timer, and game over panel.
- GameManager controls mission state and restarting the scene.
- NavMesh baked for enemy AI navigation.
- Adjust public variables in Inspector to tweak gameplay.

Enjoy developing and expanding your cyberpunk FPS!