using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    private bool missionActive = true;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void MissionFailed()
    {
        missionActive = false;
        UIManager.Instance.ShowGameOver();
    }

    public void PlayerDied()
    {
        missionActive = false;
        UIManager.Instance.ShowGameOver();
    }

    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}