using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public Slider healthBar;
    public Text ammoText;
    public Text missionTimerText;
    public GameObject gameOverPanel;
    public Image crosshair;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void UpdateHealth(int currentHealth)
    {
        healthBar.value = currentHealth;
    }

    public void UpdateAmmo(int currentAmmo, int maxAmmo)
    {
        ammoText.text = $"{currentAmmo} / {maxAmmo}";
    }

    public void UpdateMissionTimer(float timeLeft)
    {
        missionTimerText.text = $"Time Left: {timeLeft:F1}s";
    }

    public void ShowGameOver()
    {
        gameOverPanel.SetActive(true);
        Cursor.lockState = CursorLockMode.None;
    }
}