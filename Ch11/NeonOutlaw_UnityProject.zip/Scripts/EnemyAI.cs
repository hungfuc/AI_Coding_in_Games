using UnityEngine;
using UnityEngine.AI;

public class EnemyAI : MonoBehaviour
{
    public NavMeshAgent agent;
    public Transform[] patrolPoints;
    public float chaseRange = 15f;
    public float shootRange = 10f;
    public float fireRate = 1f;
    public float damage = 10f;

    private Transform player;
    private int currentPoint = 0;
    private float nextTimeToFire = 0f;
    private EnemyHealth health;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        health = GetComponent<EnemyHealth>();
        agent.SetDestination(patrolPoints[currentPoint].position);
    }

    void Update()
    {
        if (health.IsDead())
            return;

        float distance = Vector3.Distance(transform.position, player.position);

        if (distance < chaseRange)
        {
            agent.SetDestination(player.position);

            if (distance <= shootRange && Time.time >= nextTimeToFire)
            {
                ShootPlayer();
                nextTimeToFire = Time.time + 1f / fireRate;
            }
        }
        else
        {
            if (!agent.pathPending && agent.remainingDistance < 0.5f)
            {
                currentPoint = (currentPoint + 1) % patrolPoints.Length;
                agent.SetDestination(patrolPoints[currentPoint].position);
            }
        }
    }

    void ShootPlayer()
    {
        PlayerHealth playerHealth = player.GetComponent<PlayerHealth>();
        if (playerHealth != null)
        {
            playerHealth.TakeDamage((int)damage);
        }
        // Add shooting animation or effects here
    }
}