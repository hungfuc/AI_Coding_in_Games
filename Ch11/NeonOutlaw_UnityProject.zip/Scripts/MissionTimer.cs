using UnityEngine;
using UnityEngine.UI;

public class MissionTimer : MonoBehaviour
{
    public float missionDuration = 180f;
    public Text timerText;
    private float timeRemaining;
    private bool missionActive = true;

    void Start()
    {
        timeRemaining = missionDuration;
    }

    void Update()
    {
        if (!missionActive) return;

        timeRemaining -= Time.deltaTime;
        if (timeRemaining <= 0)
        {
            timeRemaining = 0;
            missionActive = false;
            GameManager.Instance.MissionFailed();
        }

        timerText.text = $"Time Left: {timeRemaining:F1}s";
    }
}